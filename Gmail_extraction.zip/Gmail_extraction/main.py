# from _future_ import print_function
import os.path
import time ,json
import re
import base64
from bs4 import BeautifulSoup
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from datetime import datetime
import requests
import credentials





def get_last_timestamp():
    filename = 'last_timestamp.txt'
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            content = file.read().strip()
            if content:
                return int(content)
    else:
        # Create a new file and store the current date format as timestamp in milliseconds
        current_timestamp_milliseconds = int(datetime.now().timestamp() * 1000)
        
        with open(filename, 'w') as file:
            file.write(str(current_timestamp_milliseconds))

        return current_timestamp_milliseconds

def update_last_timestamp(timestamp):
    with open('last_timestamp.txt', 'w') as file:
        file.write(str(timestamp))

           
def main():
    creds = credentials.get_gmail_credentials()
    last_timestamp1 = get_last_timestamp()
    last_timestamp=last_timestamp1//1000
    
    try:
        service = build('gmail', 'v1', credentials=creds)
        query = f'after:{last_timestamp} subject:"" -subject:"Re:" -in:sent'
        print(query)
        results = service.users().messages().list(userId='me', q=query).execute()
        messages = results.get('messages', [])
        if not messages:
            print('\n' + '-'*50 + '\n')
            print('No new emails found.')
            print('\n' + '-'*50 + '\n')
        else:
            for message in messages:
                #current time for a reference
                received_timestamp = int(datetime.now().timestamp() * 1000)
                msg = service.users().messages().get(userId='me', id=message['id']).execute()
                parts = msg['payload']['parts']
                for part in msg['payload']['parts']:
                    if part['filename']:
                        if 'data' in part['body']:
                            data = part['body']['data']
                        else:
                            att_id = part['body']['attachmentId']
                            att = service.users().messages().attachments().get(userId='me',messageId=message['id'],id=att_id).execute()
                            data = att['data']
                        file_data = base64.urlsafe_b64decode(data.encode('UTF-8'))
                        path = part['filename']
                        update_last_timestamp(received_timestamp)

                        with open(path, 'wb') as f:
                             f.write(file_data)

                        sgn_regex = re.compile(r'SGN', re.IGNORECASE)
                        wwn_regex = re.compile(r'WWU', re.IGNORECASE)   
                        cadentgas_regex=re.compile(r'CadentGas', re.IGNORECASE)
                        ngngas_regex = re.compile(r'NGN', re.IGNORECASE)
                        if sgn_regex.search(path):
                            url = "https://dev.dtskill.com/login"
                            headers = {
                            "Content-Type": "application/x-www-form-urlencoded",  # Indicates URL-encoded form data
                        }
                            data = {
                            "username": "admin",
                            "password": "123456"
                        }
                            response = requests.post(url, headers=headers, data=data)
                            print(response.json())
                            token=response.json()
                            final_token=token['output']['access_token']

                            url = 'https://dev.dtskill.com/api/sgngascompany'

                            headers = {
                                "Authorization": f"Bearer {final_token}",  # Bearer token for authorization
                                # "Content-Type": "multipart/form-data; boundary=<calculated when request is sent>",  # Indicates multipart form data content
                            }

                            absolute_path = os.path.abspath(path)
                            print(absolute_path)
                            # files = {'file': open(absolute_path, 'rb')}
                            file = open(absolute_path, 'rb')
                            files = {'file': file}
                            response = requests.post(url, headers=headers, files=files)
                            file.close()
                            print(f" contains SGN. Company: Cadent Gas")
                        elif wwn_regex.search(path):
                            url = "https://dev.dtskill.com/login"
                            headers = {
                            "Content-Type": "application/x-www-form-urlencoded",  # Indicates URL-encoded form data
                        }
                            data = {
                            "username": "admin",
                            "password": "123456"
                        }
                            response = requests.post(url, headers=headers, data=data)
                            print(response.json())
                            token=response.json()
                            final_token=token['output']['access_token']

                            url = 'https://dev.dtskill.com/api/wawgascompany'

                            headers = {
                                "Authorization": f"Bearer {final_token}",  # Bearer token for authorization
                                # "Content-Type": "multipart/form-data; boundary=<calculated when request is sent>",  # Indicates multipart form data content
                            }

                            absolute_path = os.path.abspath(path)
                            print(absolute_path)
                            # files = {'file': open(absolute_path, 'rb')}
                            file = open(absolute_path, 'rb')
                            files = {'file': file}
                            response = requests.post(url, headers=headers, files=files)
                            file.close()
                            print(f" contains WWN. Company: WWN")
                        elif ngngas_regex.search(path):
                            url = "https://dev.dtskill.com/login"
                            headers = {
                            "Content-Type": "application/x-www-form-urlencoded",  # Indicates URL-encoded form data
                        }
                            data = {
                            "username": "admin",
                            "password": "123456"
                        }
                            response = requests.post(url, headers=headers, data=data)
                            print(response.json())
                            token=response.json()
                            final_token=token['output']['access_token']

                            url = 'https://dev.dtskill.com/api/ngngascompany'

                            headers = {
                                "Authorization": f"Bearer {final_token}",  # Bearer token for authorization
                                # "Content-Type": "multipart/form-data; boundary=<calculated when request is sent>",  # Indicates multipart form data content
                            }

                            absolute_path = os.path.abspath(path)
                            print(absolute_path)
                            # files = {'file': open(absolute_path, 'rb')}
                            file = open(absolute_path, 'rb')
                            files = {'file': file}
                            response = requests.post(url, headers=headers, files=files)
                            file.close()
                            print(f" contains NGN. Company: NGN")
                        elif cadentgas_regex.search(path):
                            print('cadenent gas')

                            url = "https://dev.dtskill.com/login"
                            headers = {
                            "Content-Type": "application/x-www-form-urlencoded",  # Indicates URL-encoded form data
                        }
                            data = {
                            "username": "admin",
                            "password": "123456"
                        }
                            response = requests.post(url, headers=headers, data=data)
                            print(response.json())
                            token=response.json()
                            final_token=token['output']['access_token']

                            url = 'https://dev.dtskill.com/api/cadentgascompany'

                            headers = {
                                "Authorization": f"Bearer {final_token}",  # Bearer token for authorization
                                # "Content-Type": "multipart/form-data; boundary=<calculated when request is sent>",  # Indicates multipart form data content
                            }

                            absolute_path = os.path.abspath(path)
                            print(absolute_path)
                            # files = {'file': open(absolute_path, 'rb')}
                            file = open(absolute_path, 'rb')
                            files = {'file': file}
                            
                            response = requests.post(url, headers=headers, files=files)
                            file.close()
                        os.remove(path)
                        
        
                           

                # update_last_timestamp(received_timestamp)
                    

    except HttpError as error:
        print(f'An error occurred: {error}')

if __name__ == '__main__':
    while True:
        main()
        
        time.sleep(5)